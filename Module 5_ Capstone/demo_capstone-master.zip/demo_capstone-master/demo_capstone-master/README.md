# Demo Capstone for Georgetown Data Analytics Certificate Workshop

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/lwgray/demo_capstone/master)

